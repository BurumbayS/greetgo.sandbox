create function moment() returns timestamp without time zone
LANGUAGE plpgsql
AS $$
begin return current_timestamp; end
$$;
